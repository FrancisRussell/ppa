/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const run_app: () => [number, number];
export const wasm_bindgen__convert__closures_____invoke__hd1fbc08f716cccd4: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen__convert__closures_____invoke__hea3ed42a7c4061c4: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures________invoke__h75c13ea29b35f166: (a: number, b: number, c: any) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_drop_slice: (a: number, b: number) => void;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
