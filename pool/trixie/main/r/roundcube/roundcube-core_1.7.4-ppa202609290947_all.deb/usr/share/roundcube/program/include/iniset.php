<?php

use GuzzleHttp\Cookie\FileCookieJar;

/*
 +-----------------------------------------------------------------------+
 | This file is part of the Roundcube Webmail client                     |
 |                                                                       |
 | Copyright (C) The Roundcube Dev Team                                  |
 |                                                                       |
 | Licensed under the GNU General Public License version 3 or            |
 | any later version with exceptions for skins & plugins.                |
 | See the README file for a full license statement.                     |
 |                                                                       |
 | PURPOSE:                                                              |
 |   Setup the application environment required to process               |
 |   any request.                                                        |
 +-----------------------------------------------------------------------+
 | Author: Till Klampaeckel <till@php.net>                               |
 |         Thomas Bruederli <roundcube@gmail.com>                        |
 +-----------------------------------------------------------------------+
*/

// @phpstan-ignore-next-line
if (\PHP_VERSION_ID < 80100) {
    exit('Unsupported PHP version. Required PHP >= 8.1.');
}

// Backport of array_first()/array_last(), added to PHP in 8.5. Debian doesn't
// package symfony/polyfill-php85, so the two functions this codebase actually
// uses from it are reimplemented here directly (ported from that package's
// Php85.php, which Roundcube's own composer.json requires).
if (\PHP_VERSION_ID < 80500) {
    if (!function_exists('array_first')) {
        function array_first(array $array)
        {
            foreach ($array as $value) {
                return $value;
            }

            return null;
        }
    }

    if (!function_exists('array_last')) {
        function array_last(array $array)
        {
            return $array ? current(array_slice($array, -1)) : null;
        }
    }
}

// application constants
define('RCMAIL_VERSION', '1.7.4');
define('RCMAIL_START', microtime(true));

if (!defined('INSTALL_PATH')) {
    define('INSTALL_PATH', '/var/lib/roundcube/');
}

if (!defined('RCMAIL_CONFIG_DIR')) {
    define('RCMAIL_CONFIG_DIR', getenv('ROUNDCUBE_CONFIG_DIR') ?: (INSTALL_PATH . 'config'));
}

if (!defined('RCUBE_LOCALIZATION_DIR')) {
    define('RCUBE_LOCALIZATION_DIR', INSTALL_PATH . 'program/localization/');
}

define('RCUBE_INSTALL_PATH', INSTALL_PATH);
define('RCUBE_CONFIG_DIR', RCMAIL_CONFIG_DIR . '/');

// Show basic error message on fatal PHP error
register_shutdown_function('rcmail_error_handler');

// RC include folders MUST be included FIRST to avoid other
// possible not compatible libraries (i.e PEAR) to be included
// instead the ones provided by RC
$include_path = INSTALL_PATH . 'program/lib' . \PATH_SEPARATOR;
$include_path .= ini_get('include_path');

if (set_include_path($include_path) === false) {
    exit('Fatal error: ini_set/set_include_path does not work.');
}

// increase maximum execution time for php scripts
// (does not work in safe mode)
@set_time_limit(120);

// include composer autoloader (if available)
if (@file_exists(INSTALL_PATH . 'vendor/autoload.php')) {
    require INSTALL_PATH . 'vendor/autoload.php';
}

// include Roundcube Framework
require_once __DIR__ . '/../lib/Roundcube/bootstrap.php';

// register autoloader for rcmail app classes
spl_autoload_register('rcmail_autoload');

// disable use of dangerous dependencies
spl_autoload_register(static function ($classname) {
    if ($classname === FileCookieJar::class) {
        throw new \Exception("{$classname} is forbidden for security reasons.");
    }
}, true, true);

// translate PATH_INFO to _task and _action GET parameters
if (($path = rcmail_output::path_info()) && preg_match('!^([a-z]+)/([a-z]+)$!', $path, $m)) {
    if (!isset($_GET['_task'])) {
        $_GET['_task'] = $m[1];
    }
    if (!isset($_GET['_action'])) {
        $_GET['_action'] = $m[2];
    }
}

/**
 * PHP5 autoloader routine for dynamic class loading
 */
function rcmail_autoload(string $classname): bool
{
    if (str_starts_with($classname, 'rcmail')) {
        if (preg_match('/^rcmail_action_([^_]+)_(.*)$/', $classname, $matches)) {
            $filepath = INSTALL_PATH . "program/actions/{$matches[1]}/{$matches[2]}.php";
        } else {
            $filepath = INSTALL_PATH . "program/include/{$classname}.php";
        }

        if (is_readable($filepath)) {
            include_once $filepath;
            return true;
        }
    }

    return false;
}

/**
 * Show a generic error message on fatal PHP error
 */
function rcmail_error_handler()
{
    $error = error_get_last();

    if ($error && ($error['type'] === \E_ERROR || $error['type'] === \E_PARSE)) {
        rcmail_fatal_error();
    }
}

/**
 * Raise a generic error message on error
 */
function rcmail_fatal_error()
{
    if (\PHP_SAPI === 'cli') {
        echo "Fatal error: Please check the Roundcube error log and/or server error logs for more information.\n";
    } elseif (rcube_utils::request_header('X-Roundcube-Request')) {
        // Ajax request from UI
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['code' => 500, 'message' => 'Internal Server Error']);
    } else {
        if (!defined('RCUBE_FATAL_ERROR_MSG')) {
            define('RCUBE_FATAL_ERROR_MSG', INSTALL_PATH . 'program/resources/error.html');
        }

        echo file_get_contents(RCUBE_FATAL_ERROR_MSG);
    }

    exit;
}
